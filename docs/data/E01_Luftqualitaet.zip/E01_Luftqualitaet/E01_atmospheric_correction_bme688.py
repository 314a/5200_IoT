#!/usr/bin/env python
import bme680
try:                                               
    sensor = bme680.BME680(bme680.I2C_ADDR_PRIMARY)
except (RuntimeError, IOError):
    sensor = bme680.BME680(bme680.I2C_ADDR_SECONDARY)

# Oversampling Einstellungen
sensor.set_humidity_oversample(bme680.OS_2X)
sensor.set_pressure_oversample(bme680.OS_4X)
sensor.set_temperature_oversample(bme680.OS_8X)
sensor.set_filter(bme680.FILTER_SIZE_3)

# Atmosphärenkorrektur
def calculate_atmospheric_correction(temperature, air_pressure, humidity):
    # Constants
    ALPHA = 1 / 273.15
    X = (7.5 * temperature / (237.3 + temperature)) + 0.7857

    # Interim results
    denominator = 1 + ALPHA * temperature

    formula0 = 286.338
    formula1 = 0.29535 * air_pressure / denominator
    formula2 = 4.126 * 10 ** (-4) * humidity / denominator
    formula3 = 10 ** X

    # ppm-calculation
    correction_ppm = round(formula0 - (formula1 - formula2 * formula3), 2)

    # Return important values as a dictionary
    result = {
        "temperature": temperature,
        "air_pressure": air_pressure,
        "humidity": humidity,
        "correction_ppm": correction_ppm
    }
    return result


print('Sensordaten:')
try:
    while True:
        if sensor.get_sensor_data():
            result = calculate_atmospheric_correction(
                sensor.data.temperature,
                sensor.data.pressure,
                sensor.data.humidity)
            # Print the output of all returned values and format them
            output = '{0:.2f} C,{1:.2f} hPa,{2:.3f} %RH -> {3:.3f} C'.format(
                result["temperature"],
                result["air_pressure"],
                result["humidity"],
                result["correction_ppm"])
            print(output)
except KeyboardInterrupt:
    pass