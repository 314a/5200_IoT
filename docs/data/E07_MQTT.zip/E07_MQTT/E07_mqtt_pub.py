import paho.mqtt.publish as publish 
ip = "127.0.0.1"                               
topic = "iot/temperature"                             
publish.single(topic, "22.0", hostname=ip, port=1883) 