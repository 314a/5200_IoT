import paho.mqtt.client as mqtt 
ip = "127.0.0.1"                            
topic = "iot/temperature"                    

# Callback Funktion für den Verbindungsaufbau
def on_connect(client, userdata, flags, rc): 
    print("Connected - code: "+str(rc)) 
    client.subscribe(topic)                  
  
# Callback Funktion für eingehende Nachrichten
def on_message(client, userdata, msg):       
    print(msg.topic+" "+str(msg.payload))    
  
# Erstellen des MQTT Clients
client = mqtt.Client()                       
client.on_connect = on_connect                
client.on_message = on_message               
  
client.connect(ip, 1883, 60)                 
client.loop_forever()                        