########################################################
# MLX90640 Thermal Camera 
# ST7789 1.54" SPI Colour Square LCD (240x240)
########################################################
# Darstellen der Thermalbilder auf dem LCD Bildschirm

# importieren der Bibliotheken
import time,board,busio
import adafruit_mlx90640
import numpy as np
import sys
from PIL import Image
import st7789

from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont
import matplotlib as mpl

# siehe: https://matplotlib.org/stable/users/explain/colors/colormaps.html
COLOR_MAP = "turbo" # rainbow, jet, turbo, plasma, hsv
INVERSE = False

# Position des Screens vorne/hinten auf dem breakout garden
# cs:        Front: st7789.BG_SPI_CS_FRONT, Back: st7789.BG_SPI_CS_BACK
# backlight: Front: 19, Back: 18
position_cs=st7789.BG_SPI_CS_FRONT 
position_backlight=19 

# i2c = busio.I2C(board.SCL, board.SDA, frequency=400000) # setup I2C
i2c = busio.I2C(board.SCL, board.SDA) # setup I2C (without baud rate)
mlx = adafruit_mlx90640.MLX90640(i2c) # begin MLX90640 with I2C comm
mlx.refresh_rate = adafruit_mlx90640.RefreshRate.REFRESH_2_HZ # set refresh rate

# setup array for storing all 768 temperatures
frame = np.zeros((24*32,))

# Bildschirm LCD intialisieren
# Create st7789 LCD display class.
# cs=st7789.BG_SPI_CS_FRONT,  # BG_SPI_CS_BACK or BG_SPI_CS_FRONT
# backlight=19,               # 18 for back BG slot, 19 for front BG slot.
disp = st7789.ST7789(height=240,rotation=90,port=0, cs=position_cs,dc=9, backlight=position_backlight,
                     spi_speed_hz=80 * 1000 * 1000,offset_left=0, offset_top=0 )

WIDTH = disp.width
HEIGHT = disp.height
# Initialize display.
# Clear the display to a red background.
# Can pass any tuple of red, green, blue values (from 0 to 255 each).
# Get a PIL Draw object to start drawing on the display buffer.
img = Image.new('RGB', (WIDTH, HEIGHT), color=(0, 0, 0))

# Load default font.
# font = ImageFont.load_default()
# font = ImageFont.truetype('Minecraftia-Regular.ttf', 12)
font = ImageFont.truetype("Roboto-Regular.ttf", size=20)

# Farbpalette über den Palettennamen beziehen.
def get_palette(name):
    cmap = mpl.colormaps[COLOR_MAP].resampled(256)
    try:
        colors = cmap.colors
    except AttributeError:
        colors = np.array([cmap(i) for i in range(256)], dtype=float)
    arr = np.array(colors * 255).astype('uint8')
    arr = arr.reshape((16, 16, 4))
    arr = arr[:, :, 0:3]
    return arr.tobytes()


pal = get_palette(COLOR_MAP)
np.set_printoptions(precision=1) # Kommastellen für numpy print definieren

while True:
    try:
        mlx.getFrame(frame) # read MLX temperatures into frame var
        # mittlere Temperature aus der Matrix berechnen
        tmpAvg = np.mean(frame)
        # print out the average temperature from the MLX90640
        print('MLX90640 Average Temperature: {0:2.1f}C'.format(tmpAvg))       
        # print(frame)  # Matrix in der Konsole darstellen   
        # Frame numpy array für die Darstelllung vorbereiten
        arr = frame
        # Scale and clip the result to 0-255
        # Scale view to a max Temperature
        maxTemp = 50
        arr *= (255.0 / maxTemp)
        arr = np.clip(arr, 0, 255)
        # Invert the array : 0 - 255 becomes 255 - 0
        if INVERSE:
            arr *= -1
            arr += 255.0        
        # Force to int
        arr = arr.astype('uint8')    
        
        # Convert to a palette type image
        img = Image.frombytes("P", (32, 24), arr)
        img.putpalette(pal)
        img = img.convert("RGB")
        img = img.resize((240, 240), resample=Image.AFFINE)
        img = img.rotate(-90)
        
        # Frame als Bild auf den LCD Schreiben
        # img = Image.new('RGB', (WIDTH, HEIGHT), color=(0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((20, 10), f"{tmpAvg:.2f}"+"°", font=font, fill=(255, 255, 255))
                 
        # Damit Dinge auf dem Display sichtbar werden müssen diese 
        # auf die Display Hardware geschrieben werden 
        # Display the result
        disp.display(img)
        time.sleep(0.5)  # Avoid polling *too* fast
        # break # nur einmal den Code ausführen
    except ValueError:
        continue # if error, just read again
