########################################################
# MLX90640 Thermal Camera 
# ST7789 1.54" SPI Colour Square LCD (240x240)
########################################################
# Darstellen der Thermalbilder auf dem LCD Bildschirm

# importieren der Bibliotheken
import time,board,busio
import adafruit_mlx90640
import numpy as np
from PIL import Image
import st7789

from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont

# Position des Screens vorne/hinten auf dem breakout garden
# cs:        Front: st7789.BG_SPI_CS_FRONT, Back: st7789.BG_SPI_CS_BACK
# backlight: Front: 19, Back: 18
position_cs=st7789.BG_SPI_CS_FRONT 
position_backlight=19 

# i2c = busio.I2C(board.SCL, board.SDA, frequency=400000) # setup I2C
i2c = busio.I2C(board.SCL, board.SDA) # setup I2C (without baud rate)
mlx = adafruit_mlx90640.MLX90640(i2c) # begin MLX90640 with I2C comm
mlx.refresh_rate = adafruit_mlx90640.RefreshRate.REFRESH_2_HZ # set refresh rate

# setup array for storing all 768 temperatures
frame = np.zeros((24*32,))

# Bildschirm LCD intialisieren
# Create st7789 LCD display class.
# cs=st7789.BG_SPI_CS_FRONT,  # BG_SPI_CS_BACK or BG_SPI_CS_FRONT
# backlight=19,               # 18 for back BG slot, 19 for front BG slot.
disp = st7789.ST7789(height=240,rotation=90,port=0, cs=position_cs,dc=9, backlight=position_backlight,
                     spi_speed_hz=80 * 1000 * 1000,offset_left=0, offset_top=0 )

WIDTH = disp.width
HEIGHT = disp.height
# Initialize display.
# Clear the display to a red background.
# Can pass any tuple of red, green, blue values (from 0 to 255 each).
# Get a PIL Draw object to start drawing on the display buffer.
img = Image.new('RGB', (WIDTH, HEIGHT), color=(0, 0, 0))

# Load default font.
# font = ImageFont.load_default()
# font = ImageFont.truetype('Minecraftia-Regular.ttf', 12)
font = ImageFont.truetype("Roboto-Regular.ttf", size=20)

i = 0
while True:
    try:
        mlx.getFrame(frame) # read MLX temperatures into frame var
        # Frame als Bild auf den LCD Schreiben
        TEMPERATURE = f"{np.mean(frame):.2f}"+"°" 
        img = Image.new('RGB', (WIDTH, HEIGHT), color=(0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.text((20, 10), 'Average Temperature', font=font, fill=(255, 255, 255))
        draw.text((20, 40), TEMPERATURE, font=font, fill=(255, 255, 255))
        draw.text((20, 60), str(i), font=font, fill=(255, 255, 255))
        
        # print out the average temperature from the MLX90640
        print('Average MLX90640 Temperature: {0:2.1f}C ({1:2.1f}F)'.\
                format(np.mean(frame),(((9.0/5.0)*np.mean(frame))+32.0)))               
        # Write buffer to display hardware, must be called to make things visible on the
        # display!
        disp.display(img)
        i = i + 1
        time.sleep(0.5)  # Ausführungsgeschwindigkeit begrenzen
        # break # execute only once
    except ValueError:
        continue # if error, just read again
