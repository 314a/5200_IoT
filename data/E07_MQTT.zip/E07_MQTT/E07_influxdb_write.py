# This file has been written to your home directory for convenience. It is
# saved as "/home/pi/temperature-2021-09-07-09-55-36.py"

from datetime import datetime
import time

from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS

# You can generate a Token from the "Tokens Tab" in the UI
token = "<API token>"
org = "fhnw"
bucket = "iot"

client = InfluxDBClient(url="http://localhost:8086", token=token, org=org)
write_api = client.write_api(write_options=SYNCHRONOUS)

temperature = 22.0
data = Point("measures").tag("sensor","manual").tag("device","manual").field("temperature",temperature)
write_api.write(bucket=bucket, record=data)

